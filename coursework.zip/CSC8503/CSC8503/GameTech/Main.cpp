#include "../../Common/Window.h"

#include "TutorialGame.h"


using namespace NCL;
using namespace CSC8503;











/*

The main function should look pretty familar to you!
We make a window, and then go into a while loop that repeatedly
runs our 'game' until we press escape. Instead of making a 'renderer'
and updating it, we instead make a whole game, and repeatedly update that,
instead. 

This time, we've added some extra functionality to the window class - we can
hide or show the 

*/
int main() {
	Window*w = Window::CreateGameWindow("CSC8503 Game technology!", 1280, 720);
	
	if (!w->HasInitialised()) {
		return -1;
	}	
	w->ShowOSPointer(false);
	w->LockMouseToWindow(true);

	TutorialGame* g = new TutorialGame();

	while (w->UpdateWindow() && !Window::GetKeyboard()->KeyDown(KEYBOARD_ESCAPE)) {
		float dt = w->GetTimer()->GetTimeDelta() / 1000.0f;

		if (dt > 1.0f) {
			continue; //must have hit a breakpoint or something to have a 1 second frame time!
		}
		if (Window::GetKeyboard()->KeyPressed(KEYBOARD_PRIOR)) {
			w->ShowConsole(true);
		}
		if (Window::GetKeyboard()->KeyPressed(KEYBOARD_NEXT)) {
			w->ShowConsole(false);
		}
	
		
		w->SetTitle("Gametech frame time:" + std::to_string(1000.0f * dt));
		
			if (Window::GetKeyboard()->KeyPressed(KEYBOARD_P)) {
				g->SetPause(1 - g->GetPause());
			}
			if (g->GetPause() == false) {
				g->UpdateGame(dt);
			}
		
	}
	Window::DestroyGameWindow();
}