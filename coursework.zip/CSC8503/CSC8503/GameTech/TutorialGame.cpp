#include "TutorialGame.h"
#include "../CSC8503Common/GameWorld.h"
#include "../../Plugins/OpenGLRendering/OGLMesh.h"
#include "../../Plugins/OpenGLRendering/OGLShader.h"
#include "../../Plugins/OpenGLRendering/OGLTexture.h"
#include "../../Common/TextureLoader.h"

#include "../CSC8503Common/PositionConstraint.h"
#include "../CSC8503Common/NavigationGrid.h"
#include<ctime>

#include "../CSC8503Common/StateMachine.h"
#include "../CSC8503Common/StateTransition.h"
#include "../CSC8503Common/State.h"

#include <time.h>
#include <stdlib.h>
#include "NetworkedGame.h"
#include "../CSC8503Common/GameServer.h"
#include "../CSC8503Common/GameClient.h"
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>

using namespace NCL;
using namespace CSC8503;

int someData = 0;
bool isMove = false;

std::ifstream infile;
std::ofstream outfile;

clock_t startt, endt;
StateMachine* testMachine = new StateMachine();
StateMachine* moveMachine = new StateMachine();
StateMachine* chaseMachine = new StateMachine();
TutorialGame::TutorialGame()	{
	world		= new GameWorld();
	renderer	= new GameTechRenderer(*world);
	physics		= new PhysicsSystem(*world);

	forceMagnitude	= 10.0f;
	useGravity		= false;
	inSelectionMode = false;

	Debug::SetRenderer(renderer);

	InitialiseAssets();
}

/*

Each of the little demo scenarios used in the game uses the same 2 meshes, 
and the same texture and shader. There's no need to ever load in anything else
for this module, even in the coursework, but you can add it 

*/
void TutorialGame::InitialiseAssets() {
	srand((unsigned)time(NULL));
	cubeMesh = new OGLMesh("cube.msh");
	cubeMesh->SetPrimitiveType(GeometryPrimitive::Triangles);
	cubeMesh->UploadToGPU();

	sphereMesh = new OGLMesh("sphere.msh");
	sphereMesh->SetPrimitiveType(GeometryPrimitive::Triangles);
	sphereMesh->UploadToGPU();

	basicTex = (OGLTexture*)TextureLoader::LoadAPITexture("brick.png");
	floorTex= (OGLTexture*)TextureLoader::LoadAPITexture("green.jpg");
	sphereTex= (OGLTexture*)TextureLoader::LoadAPITexture("white.jpg");
	flagTex= (OGLTexture*)TextureLoader::LoadAPITexture("red.jpg");
	EnemyTex = (OGLTexture*)TextureLoader::LoadAPITexture("doge.png");
	basicShader = new OGLShader("GameTechVert.glsl", "GameTechFrag.glsl");

	InitCamera();
	InitWorld();
	
	
}

TutorialGame::~TutorialGame()	{
	delete cubeMesh;
	delete sphereMesh;
	delete basicTex;
	delete basicShader;

	delete physics;
	delete renderer;
	delete world;
}

void TutorialGame::SetPause(bool newpause) {
	pause = newpause;
}

bool TutorialGame::GetPause() {
	return pause;
}

void TutorialGame::UpdateGame(float dt) {
	//TestStateMachine();
	TestStateMachineMove();
	readfile();

	if (!inSelectionMode) {
		world->GetMainCamera()->UpdateCamera(dt);
	}
	UpdateKeys();
	
	

	world->UpdateWorld(dt);
	renderer->Update(dt);
	physics->Update(dt);

	Debug::FlushRenderables();
	renderer->Render();

	if (start == false) {
		Debug::Print("Marco's Golf Game", Vector2(390, 500));
	
		Debug::Print("Press 'Enter' to Start!", Vector2(300,300));
		Debug::Print("Press 'F1/F2' to Select Level!", Vector2(200, 200));
		Debug::Print("Press 'Esc' to Exit!", Vector2(320, 100));
	}
	//if start
	if (start == true) {
		SelectObject();
		MoveSelectedObject();
		if (useGravity) {
			Debug::Print("(G)ravity on", Vector2(10, 40));
		}
		else {
			Debug::Print("(G)ravity off", Vector2(10, 40));
		}
		Debug::Print("Hit:", Vector2(10, 60));
		Debug::Print(std::to_string(hitcount), Vector2(150, 60));
		Debug::Print("Level:", Vector2(10, 80));
		Debug::Print(std::to_string(level), Vector2(190, 80));
		Debug::Print("Press 'M' to control the move", Vector2(10, 100));
		

		//Level 1
		if (level == 1) {
			UpdateBot();
			DisplayPathfinding();
			sphtransform = sph->GetTransform();
			sphposition = sphtransform.GetWorldPosition();

			enetransform = enemy->GetTransform();
			eneposition = enetransform.GetWorldPosition();

			obstransform = obs4->GetTransform();
			obsposition = obstransform.GetWorldPosition();

			Chasing();
			
			//Set the move
			if (i == 5000) {
				move.x = -50;
			}
			if (i == -5000) {
				move.x = 50;
			}
			i = i + move.x;

			if (isMove == true) {
				obs1->GetPhysicsObject()->SetLinearVelocity(move);
				obs2->GetPhysicsObject()->SetLinearVelocity(move);
				obs3->GetPhysicsObject()->SetLinearVelocity(move);
			}

			//If is in the final
			if (880 < sphposition.x && sphposition.x < 920 && 880 < sphposition.z && sphposition.z < 920) {
				std::cout << "Goal" << std::endl;
				endt = clock();
				std::cout << "The run time is: " << (double)(endt - startt) / CLOCKS_PER_SEC << std::endl;
				std::cout << "The hit time is: " << hitcount << std::endl;
				if (readcount > hitcount) {
					std::cout << "New record! Your hit time is :" << hitcount << std::endl;
					std::cout << "New record! Your time is :" << (double)(endt - startt) / CLOCKS_PER_SEC << std::endl;
					TestNetworking();
					writefile();
				}
				InitWorld2();
				
			}
		}

		//Level 2
		if (level == 2) {
			sphtransform2 = sph2->GetTransform();
			sphposition2 = sphtransform2.GetWorldPosition();
			//Set the move
			if (j == 5000) {
				move2.z = -50;
			}
			if (j == -5000) {
				move2.z = 50;
			}
			j = j + move2.z;

			if (isMove == true) {
				obs5->GetPhysicsObject()->SetAngularVelocity(Vector3(0, 1, 0));
				obs6->GetPhysicsObject()->SetAngularVelocity(Vector3(0, 1, 0));
				obs7->GetPhysicsObject()->SetAngularVelocity(Vector3(0, 1, 0));
				obs8->GetPhysicsObject()->SetAngularVelocity(Vector3(0, 1, 0));
			}

			//If is in the final
			if (880 < sphposition2.x && sphposition2.x < 920 && 880 < sphposition2.z && sphposition2.z < 920) {
				start = false;
				std::cout << "Goal! You win!" << std::endl;
				endt = clock();
				std::cout << "The run time is: " << (double)(endt - startt) / CLOCKS_PER_SEC << std::endl;
				std::cout << "The hit time is: " << hitcount << std::endl;
			}
		}

	}
}

void TutorialGame::UpdateKeys() {

	//Start Game
	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_RETURN)) {
		start = true;
	}

	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_BACK)) {
		start = false;
		level = 0;
	}
	
	//Init Camera
	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_B)) {
		world->GetMainCamera()->SetPosition(Vector3(sphposition.x,sphposition.y+100,sphposition.z));
	}

	//Restart
	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_R)) {
		if (level == 1) {
			InitWorld(); //We can reset the simulation at any time with R
		}
		if (level == 2) {
			InitWorld2();
		}
		InitCamera();
		selectionObject = nullptr;
	}

	//Change Level 1
	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_F1)) {
		InitWorld();
		InitCamera();
		selectionObject = nullptr;
	}

	//Change Level 2
	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_F2)) {
		InitWorld2();
		InitCamera();
		selectionObject = nullptr;
	}

	//Change Gravity
	if (Window::GetKeyboard()->KeyPressed(NCL::KeyboardKeys::KEYBOARD_G)) {
		useGravity = !useGravity; //Toggle gravity!
		physics->UseGravity(useGravity);
	}
	//Running certain physics updates in a consistent order might cause some
	//bias in the calculations - the same objects might keep 'winning' the constraint
	//allowing the other one to stretch too much etc. Shuffling the order so that it
	//is random every frame can help reduce such bias.
	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_F9)) {
		world->ShuffleConstraints(true);
	}
	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_F10)) {
		world->ShuffleConstraints(false);
	}

	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_F7)) {
		world->ShuffleObjects(true);
	}
	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_F8)) {
		world->ShuffleObjects(false);
	}
	//If we've selected an object, we can manipulate it with some key presses
	if (inSelectionMode && selectionObject) {
		//Twist the selected object!
		if (Window::GetKeyboard()->KeyDown(KEYBOARD_LEFT)) {
			selectionObject->GetPhysicsObject()->AddForce(Vector3(0, 0, -100));
		}

		if (Window::GetKeyboard()->KeyDown(KEYBOARD_RIGHT)) {
			selectionObject->GetPhysicsObject()->AddForce(Vector3(0, 0, 100));
		}


		if (Window::GetKeyboard()->KeyDown(KEYBOARD_7)) {
			selectionObject->GetPhysicsObject()->AddTorque(Vector3(0, 100, 0));
		}

		if (Window::GetKeyboard()->KeyDown(KEYBOARD_8)) {
			selectionObject->GetPhysicsObject()->AddTorque(Vector3(0, -100, 0));
		}

		if (Window::GetKeyboard()->KeyDown(KEYBOARD_RIGHT)) {
			selectionObject->GetPhysicsObject()->AddTorque(Vector3(100, 0, 0));
		}

		if (Window::GetKeyboard()->KeyDown(KEYBOARD_UP)) {
			selectionObject->GetPhysicsObject()->AddForce(Vector3(100, 0, 0));
		}

		if (Window::GetKeyboard()->KeyDown(KEYBOARD_DOWN)) {
			selectionObject->GetPhysicsObject()->AddForce(Vector3(-100, 0, 0));
		}
	}

	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_C)) {
		BridgeConstraintTest();
	}
	
}

void TutorialGame::InitCamera() {
	world->GetMainCamera()->SetNearPlane(3.0f);
	world->GetMainCamera()->SetFarPlane(4200.0f);
	world->GetMainCamera()->SetPitch(-15.0f);
	world->GetMainCamera()->SetYaw(-140.0f);
	world->GetMainCamera()->SetPosition(Vector3(-950, 50, -950));
}

void TutorialGame::InitWorld2() {
	selectionObject = nullptr;
	level = 2;
	hitcount = 0;
	world->ClearAndErase();
	physics->Clear();
	InitCamera();
	//Draw Sphere and floor
	sph2 = AddSphereToWorld(Vector3(-900, 10, -900), 10, 10);
	AddFloorToWorld(Vector3(0, -100, 0));

	//Draw Wall
	AddCubeToWorld(Vector3(-990, 10, 0), Vector3(10, 100, 980), 0.0f);
	AddCubeToWorld(Vector3(990, 10, 0), Vector3(10, 100, 980), 0.0f);
	AddCubeToWorld(Vector3(0, 10, 990), Vector3(1000, 100, 10), 0.0f);
	AddCubeToWorld(Vector3(0, 10, -990), Vector3(1000, 100, 10), 0.0f);

	//Draw flag
	end2 = AddFlagToWorld(Vector3(900, -89, 900), Vector3(20, 0.1, 20), 0.0f);
	AddCubeToWorld(Vector3(900, 52, 900), Vector3(5, 140, 5), 0.0f);
	AddFlagToWorld(Vector3(865, 172, 900), Vector3(30, 20, 5), 0.0f);

	//Draw obstacle
	obs5 = AddOBBToWorld(Vector3(400, -70, 250), Vector3(20, 20, 200), 0.0f);
	obs6 = AddOBBToWorld(Vector3(0, -70, -250), Vector3(20, 20, 200), 0.0f);
	obs7 = AddOBBToWorld(Vector3(-400, -70, 250), Vector3(20, 20, 200), 0.0f);
	obs8 = AddOBBToWorld(Vector3(-600, -70, -450), Vector3(20, 20, 200), 0.0f);

	//Draw enemy
	enemy2 = AddEnemyToWorld(Vector3(rand() % (1000 - (-1000) + 1) - 1000, 0, rand() % (1000 - (-1000) + 1) - 1000), Vector3(10, 10, 10), 5.0f);
}

void TutorialGame::InitWorld() {
	
	startt = clock();
	level = 1;
	world->ClearAndErase();
	physics->Clear();
	
	//Draw Sphere and floor
	sph=AddSphereToWorld(Vector3(-900,10,-900),10,10);
	AddFloorToWorld(Vector3(0, -100, 0));

	//Draw Wall
	AddCubeToWorld(Vector3(-990, 10, 0), Vector3(10, 100, 980), 0.0f);
	AddCubeToWorld(Vector3(990, 10, 0), Vector3(10, 100, 980), 0.0f);
	AddCubeToWorld(Vector3(0, 10, 990), Vector3(1000, 100, 10), 0.0f);
	AddCubeToWorld(Vector3(0, 10, -990), Vector3(1000, 100, 10), 0.0f);

	//Draw obstacle
	AddCubeToWorld(Vector3(700, -70, 180), Vector3(20, 20, 800), 0.0f);
	AddCubeToWorld(Vector3(250, -70, -200), Vector3(20, 20, 770), 0.0f);
	obs1 = AddCubeToWorld(Vector3(250, -70, 600), Vector3(150, 20, 20), 0.0f);

	AddCubeToWorld(Vector3(-200, -70, 180), Vector3(20, 20, 800), 0.0f);
	obs2=AddCubeToWorld(Vector3(-200, -70, -650), Vector3(150, 20, 20), 0.0f);

	AddCubeToWorld(Vector3(-650, -70, -200), Vector3(20, 20, 770), 0.0f);
	obs3=AddCubeToWorld(Vector3(-650, -70, 600), Vector3(150, 20, 20), 0.0f);
	
	

	//Draw flag
	end=AddFlagToWorld(Vector3(900, -89, 900), Vector3(20, 0.1, 20), 0.0f);
	AddCubeToWorld(Vector3(900, 52, 900), Vector3(5, 140, 5), 0.0f);
	AddFlagToWorld(Vector3(865, 172, 900), Vector3(30, 20, 5), 0.0f);

	//Draw cube
	obs4 = AddEnemyToWorld(Vector3(900, -89, 900), Vector3(20, 20, 20), 1.0f);
	enemy = AddEnemyToWorld(Vector3(rand() % (1000 - (-1000) + 1) - 1000, 0, rand() % (1000 - (-1000) + 1) - 1000), Vector3(10,10,10), 5.0f);
	TestPathfinding();

	
	
	//InitCubeGridWorld(1, 1, 50.0f, 50.0f, Vector3(10, 10, 10));
	//InitMixedGridWorld(5,5,50.0f,50.0f);
	//InitSphereGridWorld(w, 1, 1, 50.0f, 50.0f, 10.0f);
	//InitCubeGridWorld(w,1, 1, 50.0f, 50.0f, Vector3(10, 10, 10));
	//InitCubeGridWorld(w, 1, 1, 50.0f, 50.0f, Vector3(8, 8, 8));

	//InitSphereCollisionTorqueTest(w);
	//InitCubeCollisionTorqueTest(w);

	//InitSphereGridWorld(w, 1, 1, 50.0f, 50.0f, 10.0f);
	//BridgeConstraintTest(w);
	//InitGJKWorld(w);

	//DodgyRaycastTest(w);
	//InitGJKWorld(w);
	//InitSphereAABBTest(w);
	//SimpleGJKTest(w);
	//SimpleAABBTest2(w);

	//InitSphereCollisionTorqueTest(w);
}

void TutorialGame::InitEmptyWorld() {
	world->ClearAndErase();
	physics->Clear();
	Debug::Print("Level:", Vector2(10, 80));
}

GameObject* TutorialGame::AddFlagToWorld(const Vector3& position, Vector3 dimensions, float inverseMass) {
	GameObject* cube = new GameObject();

	AABBVolume* volume = new AABBVolume(dimensions);

	cube->SetBoundingVolume((CollisionVolume*)volume);

	cube->GetTransform().SetWorldPosition(position);
	cube->GetTransform().SetWorldScale(dimensions);

	cube->SetRenderObject(new RenderObject(&cube->GetTransform(), cubeMesh, flagTex, basicShader));
	cube->SetPhysicsObject(new PhysicsObject(&cube->GetTransform(), cube->GetBoundingVolume()));

	cube->GetPhysicsObject()->SetInverseMass(inverseMass);
	cube->GetPhysicsObject()->InitCubeInertia();

	world->AddGameObject(cube);

	return cube;
}

/*

A single function to add a large immoveable cube to the bottom of our world

*/
GameObject* TutorialGame::AddFloorToWorld(const Vector3& position) {
	GameObject* floor = new GameObject();

	Vector3 floorSize = Vector3(1000, 10, 1000);
	AABBVolume* volume = new AABBVolume(floorSize);
	floor->SetBoundingVolume((CollisionVolume*)volume);
	floor->GetTransform().SetWorldScale(floorSize);
	floor->GetTransform().SetWorldPosition(position);

	floor->SetRenderObject(new RenderObject(&floor->GetTransform(), cubeMesh, floorTex, basicShader));
	floor->SetPhysicsObject(new PhysicsObject(&floor->GetTransform(), floor->GetBoundingVolume()));

	floor->GetPhysicsObject()->SetInverseMass(0);
	floor->GetPhysicsObject()->InitCubeInertia();

	world->AddGameObject(floor);

	return floor;
}

/*

Builds a game object that uses a sphere mesh for its graphics, and a bounding sphere for its
rigid body representation. This and the cube function will let you build a lot of 'simple' 
physics worlds. You'll probably need another function for the creation of OBB cubes too.

*/
GameObject* TutorialGame::AddSphereToWorld(const Vector3& position, float radius, float inverseMass) {
	GameObject* sphere = new GameObject();

	Vector3 sphereSize = Vector3(radius, radius, radius);
	SphereVolume* volume = new SphereVolume(radius);
	sphere->SetBoundingVolume((CollisionVolume*)volume);
	sphere->GetTransform().SetWorldScale(sphereSize);
	sphere->GetTransform().SetWorldPosition(position);

	sphere->SetRenderObject(new RenderObject(&sphere->GetTransform(), sphereMesh,sphereTex, basicShader));
	sphere->SetPhysicsObject(new PhysicsObject(&sphere->GetTransform(), sphere->GetBoundingVolume()));

	sphere->GetPhysicsObject()->SetInverseMass(inverseMass);
	sphere->GetPhysicsObject()->InitSphereInertia();

	world->AddGameObject(sphere);

	return sphere;
}

GameObject* TutorialGame::AddCubeToWorld(const Vector3& position, Vector3 dimensions, float inverseMass) {
	GameObject* cube = new GameObject();

	AABBVolume* volume = new AABBVolume(dimensions);

	cube->SetBoundingVolume((CollisionVolume*)volume);

	cube->GetTransform().SetWorldPosition(position);
	cube->GetTransform().SetWorldScale(dimensions);

	cube->SetRenderObject(new RenderObject(&cube->GetTransform(), cubeMesh, basicTex, basicShader));
	cube->SetPhysicsObject(new PhysicsObject(&cube->GetTransform(), cube->GetBoundingVolume()));

	cube->GetPhysicsObject()->SetInverseMass(inverseMass);
	cube->GetPhysicsObject()->InitCubeInertia();

	world->AddGameObject(cube);

	return cube;
}

GameObject* TutorialGame::AddOBBToWorld(const Vector3& position, Vector3 dimensions, float inverseMass) {
	GameObject* cube = new GameObject();

	OBBVolume* volume = new OBBVolume(dimensions);

	cube->SetBoundingVolume((CollisionVolume*)volume);

	cube->GetTransform().SetWorldPosition(position);
	cube->GetTransform().SetWorldScale(dimensions);

	cube->SetRenderObject(new RenderObject(&cube->GetTransform(), cubeMesh, basicTex, basicShader));
	cube->SetPhysicsObject(new PhysicsObject(&cube->GetTransform(), cube->GetBoundingVolume()));

	cube->GetPhysicsObject()->SetInverseMass(inverseMass);
	cube->GetPhysicsObject()->InitCubeInertia();

	world->AddGameObject(cube);

	return cube;
}


GameObject* TutorialGame::AddEnemyToWorld(const Vector3& position, Vector3 dimensions, float inverseMass) {
	GameObject* cube = new GameObject();

	AABBVolume* volume = new AABBVolume(dimensions);

	cube->SetBoundingVolume((CollisionVolume*)volume);

	cube->GetTransform().SetWorldPosition(position);
	cube->GetTransform().SetWorldScale(dimensions);

	cube->SetRenderObject(new RenderObject(&cube->GetTransform(), cubeMesh, EnemyTex, basicShader));
	cube->SetPhysicsObject(new PhysicsObject(&cube->GetTransform(), cube->GetBoundingVolume()));

	cube->GetPhysicsObject()->SetInverseMass(inverseMass);
	cube->GetPhysicsObject()->InitCubeInertia();

	world->AddGameObject(cube);

	return cube;
}

void TutorialGame::InitSphereGridWorld(int numRows, int numCols, float rowSpacing, float colSpacing, float radius) {
	for (int x = 0; x < numCols; ++x) {
		for (int z = 0; z < numRows; ++z) {
			Vector3 position = Vector3(x * colSpacing, radius, z * rowSpacing);
			AddSphereToWorld(position, radius);
		}
	}
	AddFloorToWorld(Vector3(0, -100, 0));
}

void TutorialGame::InitMixedGridWorld(int numRows, int numCols, float rowSpacing, float colSpacing) {
	float sphereRadius = 10.0f;
	Vector3 cubeDims = Vector3(10, 10, 10);

	for (int x = 0; x < numCols; ++x) {
		for (int z = 0; z < numRows; ++z) {
			Vector3 position = Vector3(x * colSpacing, cubeDims.y, z * rowSpacing);

			if (rand() % 2) {
				AddCubeToWorld(position, cubeDims);
			}
			else {
				AddSphereToWorld(position, sphereRadius);
			}
		}
	}
	AddFloorToWorld(Vector3(0, -100, 0));
}

void TutorialGame::InitCubeGridWorld(int numRows, int numCols, float rowSpacing, float colSpacing, const Vector3& cubeDims) {
	for (int x = 0; x < numCols; ++x) {
		for (int z = 0; z < numRows; ++z) {
			Vector3 position = Vector3(x * colSpacing, cubeDims.y, z * rowSpacing);
			AddCubeToWorld(position, cubeDims, 1.0f);
		}
	}
//	AddFloorToWorld(Vector3(10, -100, 1));
}

void TutorialGame::InitSphereCollisionTorqueTest() {
	AddSphereToWorld(Vector3(15, 0, 0), 10.0f);
	AddSphereToWorld(Vector3(-25, 0, 0), 10.0f);
	AddSphereToWorld(Vector3(-50, 0, 0), 10.0f);

	AddCubeToWorld(Vector3(-50, 0, -50), Vector3(60, 10, 10), 10.0f);

	AddFloorToWorld(Vector3(0, -100, 0));
}

void TutorialGame::InitCubeCollisionTorqueTest() {
	Vector3 cubeSize(10, 10, 10);
	AddCubeToWorld(Vector3(15, 0, 0), cubeSize, 10.0f);
	AddCubeToWorld(Vector3(-25, 0, 0), cubeSize, 10.0f);
	AddCubeToWorld(Vector3(-50, 0, 0), cubeSize, 10.0f);

	AddCubeToWorld(Vector3(-50, 0, -50), Vector3(60, 10, 10), 10.0f);

	AddFloorToWorld(Vector3(0, -100, 0));
}

void TutorialGame::InitSphereAABBTest() {
	Vector3 cubeSize(10, 10, 10);

	AddCubeToWorld(Vector3(0, 0, 0), cubeSize, 10.0f);
	AddSphereToWorld(Vector3(2, 0, 0), 5.0f, 10.0f);
}

void TutorialGame::InitGJKWorld() {
	Vector3 dimensions(20, 2, 10);
	float inverseMass = 10.0f;

	for (int i = 0; i < 2; ++i) {
		GameObject* cube = new GameObject();

		OBBVolume* volume = new OBBVolume(dimensions);

		cube->SetBoundingVolume((CollisionVolume*)volume);

		cube->GetTransform().SetWorldPosition(Vector3(0, 0, 0));
		cube->GetTransform().SetWorldScale(dimensions);

		if (i == 1) {
			cube->GetTransform().SetLocalOrientation(Quaternion::AxisAngleToQuaterion(Vector3(1, 0, 0), 90.0f));
		}

		cube->SetRenderObject(new RenderObject(&cube->GetTransform(), cubeMesh, basicTex, basicShader));
		cube->SetPhysicsObject(new PhysicsObject(&cube->GetTransform(), cube->GetBoundingVolume()));

		cube->GetPhysicsObject()->SetInverseMass(inverseMass);
		cube->GetPhysicsObject()->InitCubeInertia();

		world->AddGameObject(cube);
	}
}

void TutorialGame::BridgeConstraintTest() {
	/*float sizeMultiplier = 1.0f;

	Vector3 cubeSize = Vector3(8, 8, 8) * sizeMultiplier;

	int numLinks = 5;

	GameObject* start = AddCubeToWorld(Vector3(0, 0, 0), cubeSize, 0);

	GameObject* end = AddCubeToWorld(Vector3((numLinks + 2) * 20 * sizeMultiplier, 0, 0), cubeSize, 0);

	GameObject* previous = start;

	for (int i = 0; i < numLinks; ++i) {
		GameObject* block = AddCubeToWorld(Vector3((i + 1) * 20 * sizeMultiplier, 0, 0), cubeSize, 10.0f);
		PositionConstraint* constraint = new PositionConstraint(previous, block, 30.0f);
		world->AddConstraint(constraint);
		previous = block;
	}

	PositionConstraint* constraint = new PositionConstraint(previous, end, 30.0f);
	world->AddConstraint(constraint);*/
	Vector3 cubeSize = Vector3(8, 8, 8);

	float invCubeMass = 5;
	int numLinks = 10;
	float maxDistance = 30;
	float cubeDistance = 20;

	Vector3 startPos = Vector3(500, 100, 500);

	GameObject* start = AddCubeToWorld(startPos + Vector3(0, 0, 0), cubeSize, 0);
	GameObject* end = AddCubeToWorld(startPos + Vector3((numLinks + 2)*cubeDistance, 0, 0), cubeSize, 0);
	GameObject* previous = start;

	for (int i = 0; i < numLinks; ++i) {
		GameObject* block = AddCubeToWorld(startPos + Vector3((i + 1)*cubeDistance, 0, 0), cubeSize, invCubeMass);
		PositionConstraint* constraint = new PositionConstraint(previous, block, maxDistance);
		world->AddConstraint(constraint);
		previous = block;
	}
	PositionConstraint* constraint = new PositionConstraint(previous, end, maxDistance);
	world->AddConstraint(constraint);
}

void TutorialGame::SimpleGJKTest() {
	Vector3 dimensions		= Vector3(5, 5, 5);
	Vector3 floorDimensions = Vector3(100, 2, 100);

	GameObject* fallingCube = AddCubeToWorld(Vector3(0, 20, 0), dimensions, 10.0f);
	GameObject* newFloor	= AddCubeToWorld(Vector3(0, 0, 0), floorDimensions, 0.0f);

	delete fallingCube->GetBoundingVolume();
	delete newFloor->GetBoundingVolume();

	fallingCube->SetBoundingVolume((CollisionVolume*)new OBBVolume(dimensions));
	newFloor->SetBoundingVolume((CollisionVolume*)new OBBVolume(floorDimensions));

}

void TutorialGame::SimpleAABBTest() {
	Vector3 dimensions		= Vector3(5, 5, 5);
	Vector3 floorDimensions = Vector3(100, 2, 100);

	GameObject* newFloor	= AddCubeToWorld(Vector3(0, 0, 0), floorDimensions, 0.0f);
	GameObject* fallingCube = AddCubeToWorld(Vector3(10, 20, 0), dimensions, 10.0f);
}

void TutorialGame::SimpleAABBTest2() {
	Vector3 dimensions		= Vector3(5, 5, 5);
	Vector3 floorDimensions = Vector3(8, 2, 8);

	GameObject* newFloor	= AddCubeToWorld(Vector3(0, 0, 0), floorDimensions, 0.0f);
	GameObject* fallingCube = AddCubeToWorld(Vector3(8, 20, 0), dimensions, 10.0f);
}

/*

Every frame, this code will let you perform a raycast, to see if there's an object
underneath the cursor, and if so 'select it' into a pointer, so that it can be 
manipulated later. Pressing Q will let you toggle between this behaviour and instead
letting you move the camera around. 

*/
bool TutorialGame::SelectObject() {
	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_Q)) {
		inSelectionMode = !inSelectionMode;
		if (inSelectionMode) {
			Window::GetWindow()->ShowOSPointer(true);
			Window::GetWindow()->LockMouseToWindow(false);
		}
		else {
			Window::GetWindow()->ShowOSPointer(false);
			Window::GetWindow()->LockMouseToWindow(true);
		}
	}
	if (inSelectionMode) {
		renderer->DrawString("Press Q to change to camera mode!", Vector2(10, 0));

		if (Window::GetMouse()->ButtonDown(NCL::MouseButtons::MOUSE_LEFT)) {
			if (selectionObject) {	//set colour to deselected;
				selectionObject->GetRenderObject()->SetColour(Vector4(1, 1, 1, 1));
				selectionObject = nullptr;
			}

			Ray ray = CollisionDetection::BuildRayFromMouse(*world->GetMainCamera());

			RayCollision closestCollision;
			if (world->Raycast(ray, closestCollision, true)) {
				selectionObject = (GameObject*)closestCollision.node;
				selectionObject->GetRenderObject()->SetColour(Vector4(0, 1, 0, 1));
				return true;
			}
			else {
				return false;
			}
		}
	}
	else {
		renderer->DrawString("Press Q to change to select mode!", Vector2(10, 0));
	}
	return false;
}

/*
If an object has been clicked, it can be pushed with the right mouse button, by an amount
determined by the scroll wheel. In the first tutorial this won't do anything, as we haven't
added linear motion into our physics system. After the second tutorial, objects will move in a straight
line - after the third, they'll be able to twist under torque aswell.
*/

void TutorialGame::MoveSelectedObject() {
	renderer->DrawString("Click Force:" + std::to_string(forceMagnitude), Vector2(10, 20));
	forceMagnitude += Window::GetMouse()->GetWheelMovement() * 10.0f;
	if (!selectionObject) {
		return;//we haven't selected anything!
	}
	//Push the selected object!
	if (Window::GetMouse()->ButtonPressed(NCL::MouseButtons::MOUSE_RIGHT)) {
		Ray ray = CollisionDetection::BuildRayFromMouse(*world->GetMainCamera());

		RayCollision closestCollision;
		if (world->Raycast(ray, closestCollision, true)) {
			if (closestCollision.node == selectionObject) {
				hitcount++;
				selectionObject->GetPhysicsObject()->AddForceAtPosition(ray.GetDirection() * forceMagnitude, closestCollision.collidedAt);
			}
		}
	}
}

vector<Vector3> testNodes;

void TutorialGame::TestPathfinding() {
	NavigationGrid grid("TestGrid1.txt");
	NavigationPath outPath;

	Vector3 startPos(900, 0, 900);
	Vector3 endPos(100, 0, 200);

	bool found = grid.FindPath(startPos, endPos, outPath);

	Vector3 pos;
	testNodes.clear();
	while (outPath.PopWaypoint(pos)) {
		pos.x = pos.x * 22 - 1100;
		pos.y = -100;
		pos.z = pos.z * 22 - 1100;
		testNodes.push_back(pos);
	}
}

void TutorialGame::DisplayPathfinding() {
	for (int i = 1; i < testNodes.size(); ++i) {
		Vector3 a = testNodes[i - 1];
		Vector3 b = testNodes[i];

		/*a.x = a.x * 22 - 1100;
		a.y = -100;
		a.z = a.z * 22 - 1100;

		b.x = b.x * 22 - 1100;
		b.y = -100;
		b.z = b.z * 22 - 1100;*/

		/*std::cout << "a.x:" << obsposition.x << std::endl;
		std::cout << "b.x:" << b.x << std::endl;

		std::cout << "a.z:" << obsposition.z << std::endl;
		std::cout << "b.z:" << b.z << std::endl;*/
	//	obs4->GetTransform().SetWorldPosition(Vector3(b.x,b.y+30,b.z));
		
	//	obs4->GetPhysicsObject()->ApplyLinearImpulse(Vector3(b.x-obsposition.x, 0, b.z-obsposition.z));
		Debug::DrawLine(a, b, Vector4(0, 1, 0, 1));

	}
}

void NCL::CSC8503::TutorialGame::UpdateBot()
{
	if (!testNodes.empty()) {
		Vector3 forceDir = testNodes[0] - obs4->GetTransform().GetWorldPosition();
		forceDir.Normalise();
		Debug::DrawLine(obs4->GetTransform().GetWorldPosition(), testNodes[0], Vector4(1, 1, 1, 1));
		float length = (testNodes[0] - obs4->GetTransform().GetWorldPosition()).Length();
		if (length < 100.f) {
			testNodes.erase(testNodes.begin());
		}
		else {
			obs4->GetPhysicsObject()->ApplyLinearImpulse(forceDir * 50.f);
			//obs4->GetPhysicsObject()->SetAngularVelocity(Vector3(0, 0, 0));
		}
	}
}

void TutorialGame::Chasing() {
	
		if (eneposition.x - sphposition.x < 350 && eneposition.x - sphposition.x >-350 && eneposition.z - sphposition.z<350 && eneposition.z - sphposition.z>-350) {

			enemy->GetPhysicsObject()->AddForce(Vector3(sphposition.x - eneposition.x, 0, sphposition.z - eneposition.z));
			if (eneposition.x - sphposition.x < 20 && eneposition.x - sphposition.x >-20 && eneposition.z - sphposition.z<20 && eneposition.z - sphposition.z>-20) {
				if (forceMagnitude > 100.0f || forceMagnitude < -100.0f) {
					std::cout << "You destroyed the enemy!" << std::endl;
					enemy->GetTransform().SetWorldPosition(Vector3(rand() % (1000 - (-1000) + 1) - 1000, 0, rand() % (1000 - (-1000) + 1) - 1000));

				}
				else {
					std::cout << "Restart!" << std::endl;
					if (level == 1) {
						InitWorld(); //We can reset the simulation at any time with R
					}
					if (level == 2) {
						InitWorld2();
					}
					InitCamera();
					selectionObject = nullptr;
				}
			}
		}
		else {
			Patrol();

		}
	

}

void TutorialGame::Patrol() {

		enemy->GetPhysicsObject()->AddForce(Vector3(rand() % (500 - (-500) + 1) - 500, 0, rand() % (500 - (-500) + 1) - 500));
	
	
}

void TutorialGame::TestStateMachine() {
	
	StateFunc AFunc = [](void* data) {
		int* realData = (int*)data;
		(*realData) ++;
		std::cout << "In State A!" <<someData<< std::endl;
	};
	StateFunc BFunc = [](void* data) {
		int* realData = (int*)data;
		(*realData)--;
		std::cout << "In State B!" <<someData<< std::endl;
	};
	StateFunc CFunc = [](void* data) {
		int* realData = (int*)data;
		(*realData)--;
		std::cout << "In State C!" <<someData<< std::endl;
	};
	GenericState* stateA = new GenericState(AFunc, (void*)&someData);
	GenericState* stateB = new GenericState(BFunc, (void*)&someData);
	GenericState* stateC = new GenericState(CFunc, (void*)&someData);

	testMachine->AddState(stateA);
	testMachine->AddState(stateB);
	testMachine->AddState(stateC);

	GenericTransition<int&, int>* transitionA = new GenericTransition<int&, int>(GenericTransition<int&, int>::GreaterThanTransition,someData, 1, stateA, stateB);
	GenericTransition<int&, int>* transitionB = new GenericTransition<int&, int>(GenericTransition<int&, int>::EqualsTransition, someData,1, stateB, stateC);
	GenericTransition<int&, int>* transitionC = new GenericTransition<int&, int>(GenericTransition<int&, int>::EqualsTransition, someData, 0, stateC, stateA);

	testMachine->AddTransition(transitionA);
	testMachine->AddTransition(transitionB);
	testMachine->AddTransition(transitionC);

	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_N)) {
		testMachine->Update();
	}

	/*for (int i = 0; i < 100; i++) {
		testMachine->Update();
	}*/

	//delete testMachine;
}

void TutorialGame::TestStateMachineMove() {
	StateFunc Move = [](void* data) {
		isMove = (bool*)data;
		isMove=true;
		std::cout << "Move!" << std::endl;
	};
	StateFunc notMove = [](void* data) {
		isMove = (bool*)data;
		isMove = false;
		std::cout << "not Move!" << std::endl;
	};

	GenericState* stateA = new GenericState(Move, (void*)&isMove);
	GenericState* stateB = new GenericState(notMove, (void*)&isMove);

	moveMachine->AddState(stateA);
	moveMachine->AddState(stateB);

	GenericTransition<bool&, bool>* transitionA = new GenericTransition<bool&, bool>(GenericTransition<bool&, bool>::EqualsTransition, isMove, true, stateA, stateB);
	GenericTransition<bool&, bool>* transitionB = new GenericTransition<bool&, bool>(GenericTransition<bool&, bool>::EqualsTransition, isMove, false, stateB, stateA);

	moveMachine->AddTransition(transitionA);
	moveMachine->AddTransition(transitionB);

	if (Window::GetKeyboard()->KeyPressed(KEYBOARD_M)) {
		moveMachine->Update();
	}
}

class TestPacketReceiver :public PacketReceiver {
public:
	TestPacketReceiver(string name) {
		this->name = name;
	}

	void ReceivePacket(int type, GamePacket* payload, int source) {
		if (type == String) {
			StringPacket* realPacket = (StringPacket*)payload;

			string msg = realPacket->GetStringFromData();
			std::cout << name << " received message : " << msg << std::endl;
		}
	}
protected:
	string name;
};

void TutorialGame::TestNetworking() {
	NetworkBase::Initialise();
	TestPacketReceiver serverReceiver("Server");
	TestPacketReceiver clientReceiver("Client");

	int port = NetworkBase::GetDefaultPort();

	GameServer * server = new GameServer(port, 1);
	GameClient * client = new GameClient();

	server->RegisterPacketHandler(String, &serverReceiver);
	client->RegisterPacketHandler(String, &clientReceiver);

	bool canConnect = client->Connect(127, 0, 0, 1, port);

	if (level == 1) {
		for (int i = 0; i < 4; ++i) {
			server->SendGlobalMessage(StringPacket(" New record! Your hit time is :" + std::to_string(hitcount)));
			server->SendGlobalMessage(StringPacket("New record! Your time is :" + std::to_string((double)(endt - startt) / CLOCKS_PER_SEC)));
			client->SendPacket(StringPacket(" New record! Your hit time is : " + std::to_string(hitcount)));
			client->SendPacket(StringPacket("New record! Your time is :" + std::to_string((double)(endt - startt) / CLOCKS_PER_SEC)));
			server->UpdateServer();
			client->UpdateClient();
			std::this_thread::sleep_for(std::chrono::milliseconds(10));
		}
	}

	NetworkBase::Destroy();
}

void TutorialGame::readfile() {
	infile.open("score.txt");
	string strread;
	std::getline(infile, strread);
	str2int(readcount, strread);
	infile.close();
}

void TutorialGame::writefile() {
	outfile.open("score.txt");
	outfile << hitcount << std::endl;
	outfile << (double)(endt - startt) / CLOCKS_PER_SEC << std::endl;
	outfile.close();
}

void TutorialGame::str2int(int &int_temp, const string &string_temp)
{
	std::stringstream stream(string_temp);
	stream >> int_temp;
}

