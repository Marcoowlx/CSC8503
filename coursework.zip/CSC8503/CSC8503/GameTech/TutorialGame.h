#pragma once
#include "GameTechRenderer.h"
#include "../CSC8503Common/PhysicsSystem.h"
#include<ctime>

namespace NCL {
	namespace CSC8503 {
		class TutorialGame		{
		public:
			TutorialGame();
			~TutorialGame();


			virtual void UpdateGame(float dt);

			void SetPause(bool newpause);

			bool GetPause();

		

		protected:
			void InitialiseAssets();

			void InitCamera();
			void UpdateKeys();

			void InitWorld();

			void InitWorld2();

			void InitEmptyWorld();


			/*
			These are some of the world/object creation functions I created when testing the functionality
			in the module. Feel free to mess around with them to see different objects being created in different
			test scenarios (constraints, collision types, and so on). 
			*/
			void InitSphereGridWorld(int numRows, int numCols, float rowSpacing, float colSpacing, float radius);
			void InitMixedGridWorld(int numRows, int numCols, float rowSpacing, float colSpacing);
			void InitCubeGridWorld(int numRows, int numCols, float rowSpacing, float colSpacing, const Vector3& cubeDims);
			void InitSphereCollisionTorqueTest();
			void InitCubeCollisionTorqueTest();
			void InitSphereAABBTest();
			void InitGJKWorld();
			void BridgeConstraintTest();
			void SimpleGJKTest();
			void SimpleAABBTest();
			void SimpleAABBTest2();

			bool SelectObject();
			void MoveSelectedObject();

			void TestPathfinding();

			void DisplayPathfinding();

			void UpdateBot();

			void Chasing();
			void Patrol();
			void TestStateMachine();
			void TestStateMachineMove();
			void TestNetworking();

			void readfile();
			void writefile();
			void str2int(int &int_temp, const string &string_temp);

			GameObject* AddFloorToWorld(const Vector3& position);
			GameObject* AddSphereToWorld(const Vector3& position, float radius, float inverseMass = 10.0f);
			GameObject* AddCubeToWorld(const Vector3& position, Vector3 dimensions, float inverseMass = 10.0f);
			GameObject* AddFlagToWorld(const Vector3& position, Vector3 dimensions, float inverseMass);
			GameObject* AddEnemyToWorld(const Vector3& position, Vector3 dimensions, float inverseMass);
			GameObject* AddOBBToWorld(const Vector3& position, Vector3 dimensions, float inverseMass);

			GameTechRenderer*	renderer;
			PhysicsSystem*		physics;
			GameWorld*			world;

			bool useGravity;
			bool inSelectionMode;

			float		forceMagnitude;

			GameObject* selectionObject = nullptr;

			OGLMesh*	cubeMesh	= nullptr;
			OGLMesh*	sphereMesh	= nullptr;
			OGLTexture* basicTex	= nullptr;
			OGLTexture* floorTex = nullptr;
			OGLTexture* sphereTex = nullptr;
			OGLTexture* flagTex = nullptr;
			OGLTexture* EnemyTex = nullptr;
			OGLShader*	basicShader = nullptr;
			GameObject* obs1 = nullptr;
			GameObject* obs2 = nullptr;
			GameObject* obs3 = nullptr;
			GameObject* obs4 = nullptr;
			GameObject* obs5 = nullptr;
			GameObject* obs6 = nullptr;
			GameObject* obs7 = nullptr;
			GameObject* obs8 = nullptr;
			GameObject* sph = nullptr;
			GameObject* sph2 = nullptr;
			GameObject* end = nullptr;
			GameObject* end2 = nullptr;
			GameObject* enemy = nullptr;
			GameObject* enemy2 = nullptr;

			Vector3 sphposition;
			Transform sphtransform;

			Vector3 sphposition2;
			Transform sphtransform2;

			Vector3 obsposition;
			Transform obstransform;

			Vector3 eneposition;
			Transform enetransform;

			Vector3 eneposition2;
			Transform enetransform2;

			int hitcount = 0;
			int readcount = 0;

			int i = 0;
			int j = 0;
			Vector3 move=Vector3(50,0,0);
			Vector3 move2 = Vector3(0, 0, 50);

			bool pause = false;

			int level = 0;

			bool start = false;

			
			
		};
	}
}

