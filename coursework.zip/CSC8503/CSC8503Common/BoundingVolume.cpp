#include "BoundingVolume.h"

using namespace NCL;

BoundingVolume::BoundingVolume()
{
}


BoundingVolume::~BoundingVolume()
{
}
