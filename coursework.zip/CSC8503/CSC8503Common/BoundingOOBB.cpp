#include "BoundingOOBB.h"

using namespace NCL;

BoundingOOBB::BoundingOOBB()
{
	type = BoundingType::OOBB;
}


BoundingOOBB::~BoundingOOBB()
{
}
